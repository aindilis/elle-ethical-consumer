//package com.elle.bleaf;
//
//import android.view.View;
//
//public class EvidenceData {
//	String text;
//	BeliefData belief;
//	String company;
//	int visible;
//	
//	public EvidenceData(String pCompany, BeliefData pBelief, String pText){
//		company = pCompany;
//		belief = pBelief;
//		text = pText;
//		visible = View.GONE;
//	}
//	
//	public BeliefData getBelief(){
//		return belief;
//	}
//	
//	public String getText(){
//		return text;
//	}
//	
//	public int getVisibility(){
//		return visible;
//	}
//	
//	public void setVisibility(int pVisible){
//		visible = pVisible;
//	}
//}
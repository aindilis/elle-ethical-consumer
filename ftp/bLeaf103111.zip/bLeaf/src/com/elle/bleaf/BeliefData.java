package com.elle.bleaf;

public class BeliefData {
	public String name;
	public int icon;
	
	public BeliefData(String pName, int pIcon){
		name = pName;
		icon = pIcon;
	}

}

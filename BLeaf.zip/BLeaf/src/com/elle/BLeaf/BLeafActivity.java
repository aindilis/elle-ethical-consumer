package com.elle.BLeaf;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.os.Bundle;
import android.util.Xml;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.elle.BLeaf.Message.Message;

public class BLeafActivity extends Activity {
	/** Called when the activity is first created. */

	static final String PUB_DATE = "pubDate";
	static final String DESCRIPTION = "description";
	static final String LINK = "link";
	static final String TITLE = "title";
	static final String ITEM = "item";
	static final String CHANNEL = "channel";
	
	ArrayList<Message> messages = null;
	public ArrayList<String> history;
	public ListView mList;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);   
		final Button button = (Button) findViewById(R.id.button1);
		final TextView text = (TextView) findViewById(R.id.textView4);

		button.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// pretend that the url of the RSS feed was filled out in the GUI
				// pretend that the rss feed was downloaded, parsed, and BLeaf tag extracted and url got
				String link = "http://frdcsa.org/~andrewdo/projects/sample.rss";
				try {
					URL url = new URL(link);                	    
					try {
						InputStream stream = url.openConnection().getInputStream();
						try {
							XmlPullParser parser = Xml.newPullParser();
							try {
								// auto-detect the encoding from the stream
								parser.setInput(stream, null);
								int eventType = parser.getEventType();
								Message currentMessage = null;
								boolean done = false;
								while (eventType != XmlPullParser.END_DOCUMENT && !done){
									String name = null;
									switch (eventType){
									case XmlPullParser.START_DOCUMENT:
										messages = new ArrayList<Message>();
										break;
									case XmlPullParser.START_TAG:
										name = parser.getName();
										if (name.equalsIgnoreCase(ITEM)){
											currentMessage = new Message();
										} else if (currentMessage != null){
											if (name.equalsIgnoreCase(LINK)){
												currentMessage.setLink(parser.nextText());
											} else if (name.equalsIgnoreCase(DESCRIPTION)){
												currentMessage.setDescription(parser.nextText());
											} else if (name.equalsIgnoreCase(PUB_DATE)){
												currentMessage.setDate(parser.nextText());
											} else if (name.equalsIgnoreCase(TITLE)){
												currentMessage.setTitle(parser.nextText());
											}    
										}
										break;
									case XmlPullParser.END_TAG:
										name = parser.getName();
										if (name.equalsIgnoreCase(ITEM) && 
												currentMessage != null){
											messages.add(currentMessage);
										} else if (name.equalsIgnoreCase(CHANNEL)){
											done = true;
										}
										break;
									}
									eventType = parser.next();
								}
							} catch (Exception e) {
								throw new RuntimeException(e);
							}
						} catch (Exception e) {
							throw new RuntimeException(e);
						} 
					} catch (IOException e) {
						throw new RuntimeException(e);
					}
				} catch (MalformedURLException e) {
					throw new RuntimeException(e);
				}
				if (messages != null) {
					Iterator<Message> itr = messages.iterator();
					while (itr.hasNext()) {
						Message mesg = itr.next();
						// find a match of the URL information for the XML File
						Pattern p = Pattern.compile("StartBLeaf (.+?) EndBLeaf",Pattern.DOTALL);
						Matcher m = p.matcher(mesg.getDescription());						
						boolean matchFound = m.find();
						if (matchFound) {
						    // Get all groups for this match
						    for (int i=0; i<=m.groupCount(); i++) {
						        if (i == 1) {
						        	String link2 = m.group(i);						        
						        	text.setText(text.getText()+"\nExtracted Announcement Link "+link2);
						        	try {
										URL url2 = new URL(link2);
										ProcessAnnouncement(url2);
						    		} catch (MalformedURLException e) {
										throw new RuntimeException(e);
									}
						        }
						    }
						}
					}
				}
			}
		});
	}
	
	public void ProcessAnnouncement(URL url) {
		// need to create an object representing the Boycott
	
	}
}